package com.rb.smart.bookstore.entity;

import org.springframework.hateoas.RepresentationModel;

public class BaseEntity extends RepresentationModel {

}
