package com.rb.smart.bookstore.cache;

public interface CacheManager {

	Object getCachedObj(String string);

}
